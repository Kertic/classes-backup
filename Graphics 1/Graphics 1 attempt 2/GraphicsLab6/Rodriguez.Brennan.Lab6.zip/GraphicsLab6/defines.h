#pragma once


#define SCREEN_WIDTH 500
#define SCREEN_HEIGHT 500
#define SCREEN_SIZE SCREEN_WIDTH * SCREEN_HEIGHT

#define _RASTERDEBU //_RASTERDEBUG
#define _SHADERDEBU //_SHADERDEBUG

#define PI 3.14159265358979f


#define DRAGON_ARRAY greendragon_pixels


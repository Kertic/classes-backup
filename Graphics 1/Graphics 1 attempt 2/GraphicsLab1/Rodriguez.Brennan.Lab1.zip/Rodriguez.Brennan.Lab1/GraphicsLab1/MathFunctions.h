#pragma once

#include "defines.h"


int From2Dto1D(int _x, int _y, int _minX, int _minY, int _maxX, int _maxY);
float Lerp(float min, float max, float ratio);
#pragma once
#include "MathFunctions.h"

static void(*PixelShader)(unsigned int);
static void(*VertexShader)(Vector);

#pragma region Pixel shader globals
static unsigned int customColor = 0;
#pragma endregion
#pragma region Vertex Shader globals

#pragma endregion



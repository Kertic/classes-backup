#include "shaders.h"

Vector RotateVector(Vector inVector)
{
	Vector returnVector;
	returnVector = MatrixTimesVector(ZRotationMatrix(5 * elapsedTime), inVector);
	return returnVector;
}
